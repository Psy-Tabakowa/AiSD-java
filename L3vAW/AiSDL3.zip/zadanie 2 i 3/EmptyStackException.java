package pl.pwr.stack;

public class EmptyStackException extends Exception{

}
