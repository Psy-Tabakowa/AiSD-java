package pl.pwr.stack;

public class BottomOfStackException extends Exception {
}
