package pl.pwr.stack;

public class FullStackException extends Exception{

}
